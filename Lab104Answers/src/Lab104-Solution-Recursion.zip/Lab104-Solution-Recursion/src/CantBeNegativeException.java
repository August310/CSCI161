
/**
 * This class was created to make the code more readable.
 * 
 * @author latimer
 */
//public class CantBeNegativeException extends IllegalArgumentException {
public class CantBeNegativeException extends IllegalArgumentException {

    public CantBeNegativeException( String message )
    {
        super( message );
    }
}
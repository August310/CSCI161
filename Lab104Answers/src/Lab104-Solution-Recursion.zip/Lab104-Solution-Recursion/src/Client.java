
/**
 * Lab104 is implements 3 basic recursive algorithm.
 *   -- Determine the log-base-2 of a number
 *   -- Determine the product of two positive integers
 *   -- Search a directory structure for all occurrences of a file.
 *
 *   Caller methods are used to keep the recursive algorithms simple.
 * 
 * This Lab uses a menu based client
 *
 * @author latimer
 * @version 20240205
 */

import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        
        Scanner keyScan = new Scanner(System.in);

        boolean quit = false;

        // loop until the user wants to quit
        while (!quit) {
            System.out.println("==========  Menu  ==========");
            System.out.println(" A)  log-base-2 ");
            System.out.println(" B)  product ");
            System.out.println(" C)  find ");
            System.out.println(" Q)  Quit ");

            System.out.print("Enter choice: ");
            String choice = keyScan.nextLine();

            switch (choice) {
                case "A":
                case "a":
                    Recursion.callLogBase2(); break;
                case "B":
                case "b":
                    Recursion.callProduct();
                    break;
                case "C":
                case "c":
                    Recursion.callFind(); break;
                case "Q":
                case "q":
                    quit = true; break;

                default:
                    System.out.println("Invalid Choice, Try Again\n");
            }
        }
    }
}


import java.io.File;
import java.util.Scanner;

/**
 *
 * @author latimer
 */
public class MyUtil {

    /**
     * Asks the user to enter an absolute path of a directory.
     * Checks user input and loops until an existing path to a directory is entered.
     * @return 
     */
    public static File getValidDirectory() {

        Scanner scan = new Scanner(System.in);

        boolean validDirectory = false;

        File directory = null;

        while (!validDirectory) {

            System.out.print("Enter the absloute path for the directory:  ");

            String absolutePath = scan.nextLine();

            directory = new File(absolutePath);

            //System.out.println(directory.getAbsolutePath());
            if (!directory.exists()) {

                System.out.printf("ERROR: Directory %s does not exits.  \nType QUIT to exit  OR  ", absolutePath);

                // Allow user to give up, exit the method and return null.
                if (absolutePath.equalsIgnoreCase("QUIT")) {
                    return null;
                }

            } else {
                validDirectory = true;
            }
        }

        return directory;

    }
    
    /**
     * Asks the user to enter a String that represents a filename.
     * Check to see that the String does not contain any illegal characters.
     * Loop until a valid filename is entered.
     * @return 
     */
    public static String getValidFileName( ){
        Scanner scan = new Scanner( System.in );
        
        boolean validFileName = false;
        String fileName = null;
        
        while ( !validFileName ){
        System.out.print("Enter a filename: ");
        fileName = scan.nextLine();
        validFileName = isValidFilename( fileName );              
        }
        return fileName;
    }
    
    /**
     * Checks a String to make sure that it does not contain any 
     * characters that are not allowed in a filename.
     * @param fileName
     * @return 
     */
    public static boolean isValidFilename(String fileName) {
        for (int i = 0; i < fileName.length(); i++) {
            char c = fileName.charAt(i);
            switch (c) {
                case '/' : 
                case '\\': 
                case '*' : 
                case '"' :    
                case '<' :
                case '>' :    
                case ':' :
                case '|' :
                case '?' : return false;     
            }
        }
        return true;
    }
     
    /**
     * Tests to see if a String represents a vaild integer.
     * @param s
     * @return 
     */
    public static boolean isInteger( String s ){
        try{
            Integer.parseInt(s);
            return true;
        }
        catch (NumberFormatException e )
        {
            return false;
        }
    }
 
    /**
     * returns true if it is passed a positive integer
     * @param i
     * @return 
     */
    public static boolean isPositive( int i ){
        return ( i >= 0 );
    }    
   
    /**
     * Ask the user to enter a positive integer value from the keyboard.
     * Reads keyboard input as a String
     * Uses Integer.parseInt to determine if it is a value integer
     * Checks to see if the integer is positive
     * Looks until an integer > 0 is entered
     * @return 
     */
    public static int getPositiveInteger(){
        Scanner scan = new Scanner(System.in);
        boolean validN = false;
        int n = -1;
        while (!validN) {
            try {
                System.out.print("Enter a positive integer value: ");
                String input = scan.nextLine();
                int value = Integer.parseInt(input);
                if (value <= 0) {
                    throw new CantBeNegativeException("Error: Integer must be > 0.");
                }               
                n = value;
                validN = true;
            } catch (NumberFormatException nfe) {
                System.out.println("Error: You must enter and Integer.");
            } catch (CantBeNegativeException cbne) {
                System.out.println("Error: " + cbne.getMessage());
            }
        }             
        return n;
    }
}

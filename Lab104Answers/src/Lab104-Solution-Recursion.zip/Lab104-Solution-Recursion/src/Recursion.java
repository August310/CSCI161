
import java.io.File;

/**
 *
 * @author latimer
 * @version 20240105
 */
public class Recursion {

    private final static boolean TEST = true;

    /**
     * Asks user to enter a positive integer > 0. 
     * log( 0 ) is not defined since
     * no number raised to an exponent can have a value of zero.
     */
    public static void callLogBase2() {
        int n;
        if (TEST) {
            n = 1024;
        } else {
            n = MyUtil.getPositiveInteger();
        }
        int answer = logBase2(n);
        System.out.printf("logBase2( %,d ) = %d\n", n, answer);
    }

    /**
     * Computes the log-Base-2 of n A recursive algorithm to compute the integer
     * part of the base-two logarithm of n using only addition and integer
     * division. 
     * Textbook problem C-5.11 on page 221
     *
     * @param n
     * @return
     */
    private static int logBase2(int n) {

        // base case, logBase2 of any number < 2 is 1, i.e. 2 ^ 0 = 1
        if (n < 2) {
            return 0;
        }
        // general case
        // count number of times you integer divide n by 2 to get to 0.
        return 1 + logBase2(n / 2);
    }

    public static void callProduct() {

        System.out.println("Computing the product of two positive integers.");
        int m;
        int n;

        if (TEST) {
            m = 5;          // TEST data
            n = 5;          // TEST data
        } else {
            m = MyUtil.getPositiveInteger();
            n = MyUtil.getPositiveInteger();
        }
        int answer;
        if ( m == 0 || n == 0 )
            answer = 0;
        else
            answer = product(m, n);
        System.out.printf("product( %d, %d ) = %d\n", m, n, answer);

    }

    /**
     * Computes the product of m and n, i.e. m X n A recursive algorithm to
     * compute the product of two positive integers, m and n, using only
     * addition and subtraction. 
     * Textbook problem C-5.13 on page 221
     *
     * @param n
     * @return
     */
    private static int product(int m, int n) {
        // TEST for zero not needed when callProduct is used.
        if (m == 0 || n == 0) {
            return 0;    // base case
        }
        if (m == 1) {
            return n;                        // base case
        }
        return n + product(m - 1, n);        // general case
    }

    public static void callFind() {
        System.out.println("Finding files");

        String startString; // Name of directory to start searching in.
        File start;         // File of directory to start searching in.
        String target;      // Name of the file that you are looking for.

        if (TEST) {
            startString = "C:\\data";           // TEST data
            start = new File(startString);      // TEST data
            target = "data.txt";                // TEST data        
        } else {
            start = MyUtil.getValidDirectory();
            target = MyUtil.getValidFileName();
        }
        find(start, target);
    }

    /**
     * Recursively searches the directory structure starting at the
     * startDirectory looking for files named target.
     * Prints the absolute path to each file whose name matches target.
     * Textbook problem P-5.27 on page 223
     * @param startDirectory
     * @param target 
     */
    private static void find(File startDirectory, String target) {

        File[] fileTable = startDirectory.listFiles();

        if (fileTable != null) {  // Don't process directories that have null file tables (i.e. empty directories).

            for (int i = 0; i < fileTable.length; i++) {
                // base case, file table entry is a file
                if (fileTable[i].isFile() && target.equalsIgnoreCase(fileTable[i].getName())) {
                    System.out.println("Found: " + fileTable[i].getAbsolutePath());
                } else {
                    // general case, file table entry is a directory   
                    find(fileTable[i], target);
                }
            }
        }
    }
}
